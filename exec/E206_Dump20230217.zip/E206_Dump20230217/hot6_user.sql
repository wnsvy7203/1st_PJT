-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: i8e206.p.ssafy.io    Database: hot6
-- ------------------------------------------------------
-- Server version	8.0.32-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `dtype` varchar(31) NOT NULL,
  `user_seq` bigint NOT NULL,
  `first_address` varchar(255) NOT NULL,
  `last_address` varchar(255) NOT NULL,
  `zip_code` varchar(5) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `user_password` varchar(16) NOT NULL,
  `user_phone_number` varchar(11) NOT NULL,
  `user_profile_image_url` varchar(255) DEFAULT NULL,
  `user_code` varchar(2) NOT NULL,
  `user_delete_date` datetime(6) DEFAULT NULL,
  `user_id` varchar(20) NOT NULL,
  `user_register_date` datetime(6) NOT NULL,
  PRIMARY KEY (`user_seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('MASTER',1,'부산광역시 강서구','송정동','46754','myikn.999@gmail.com','학원장','qwer1234!','01034295100','https://ssafy-hot-six.s3.ap-northeast-2.amazonaws.com/3152902.png','UM',NULL,'master1','2023-02-16 15:46:59.200000'),('TEACHER',5,'부산 강서구 르노삼성대로 14','101동 101호','46760','ssafy@ssafy.io','장시우','qwer1234!','01012345678','','UT',NULL,'teacher1','2023-02-16 15:58:14.207000'),('TEACHER',8,'부산 강서구 르노삼성대로 14','123','46760','ssafy@ssafy.io','해리포터','qwer1234!','01012345678','https://ssafy-hot-six.s3.ap-northeast-2.amazonaws.com/%ED%95%B4%EB%A6%AC%ED%8F%AC%ED%84%B0.jpg','UT',NULL,'teacher2','2023-02-16 16:00:18.066000'),('PARENT',15,'부산 강서구 르노삼성대로 61','123','46758','ssafy@ssafy.io','로널드위즐리','qwer1234!','01012345678','https://ssafy-hot-six.s3.ap-northeast-2.amazonaws.com/%EB%A1%A0%20%EC%9C%84%EC%A6%90%EB%A6%AC.jpg','UP',NULL,'teacher3','2023-02-16 16:10:35.106000'),('MASTER',16,'서울특별시 강남구','테헤란로 212','06220','master2@master2.com','학원장2','qwer1234!','01012345678',NULL,'UM',NULL,'master2','2023-02-16 16:11:11.462000'),('MASTER',18,'대전광역시 유성구','동서대로 98-39','34153','master3@master3.com','학원장3','qwer1234!','01023456789',NULL,'UM',NULL,'master3','2023-02-16 16:13:38.962000'),('PARENT',19,'부산 강서구 르노삼성대로 255','123','46726','ssafy@ssafy.io','헤르미온느','qwer1234!','01012345678','https://ssafy-hot-six.s3.ap-northeast-2.amazonaws.com/%ED%97%A4%EB%A5%B4%EB%AF%B8%EC%98%A8%EB%8A%90.jpg','UP',NULL,'teacher4','2023-02-16 16:14:32.849000'),('TEACHER',21,'부산 강서구 르노삼성대로 372','1233','46726','ssafy@ssafy.io','닥쳐말포이','qwer1234!','01012345678','https://ssafy-hot-six.s3.ap-northeast-2.amazonaws.com/%EB%A7%90%ED%8F%AC%EC%9D%B4.jpg','UT',NULL,'teacher5','2023-02-16 16:16:07.039000'),('MASTER',24,'경상북도 구미시','3공단3로 302','39388','master4@master4.com','학원장4','qwer1234!','01034567890',NULL,'UM',NULL,'master4','2023-02-16 16:17:50.558000'),('TEACHER',31,'부산 강서구 르노삼성대로 381','23','46726','ssafy@ssafy.io','최치열','qwer1234!','01012345678','https://ssafy-hot-six.s3.ap-northeast-2.amazonaws.com/%EC%B5%9C%EC%B9%98%EC%97%B4.jpg','UT',NULL,'teacher6','2023-02-16 16:24:57.959000'),('PARENT',35,'부산 강서구 르노삼성대로 563','543','46773','ssafy@ssafy.io','김민수','qwer1234!','01012345678','','UP',NULL,'parent1','2023-02-16 16:26:16.782000'),('MASTER',40,'광주광역시 광산구','오선동 271','62218','master5@master5.com','학원장5','qwer1234!','01045678901',NULL,'UM',NULL,'master5','2023-02-16 16:27:39.564000'),('PARENT',41,'부산 강서구 르노삼성대로 61','123','46758','ssafy@ssafy.io','전도연','qwer1234!','01012345657','https://ssafy-hot-six.s3.ap-northeast-2.amazonaws.com/%EC%A0%84%EB%8F%84%EC%97%B0.jpg','UP',NULL,'parent2','2023-02-16 16:27:43.638000'),('PARENT',42,'부산 강서구 르노삼성대로 381','13','46726','ssafy@ssafy.io','박연진','qwer1234!','01023457980','https://ssafy-hot-six.s3.ap-northeast-2.amazonaws.com/%EB%B0%95%EC%97%B0%EC%A7%84.jpg','UP',NULL,'parent3','2023-02-16 16:29:13.470000'),('PARENT',44,'부산 강서구 르노삼성대로 566','14','46773','ssafy@ssafy.io','한서진','qwer1234!','01019807258','https://ssafy-hot-six.s3.ap-northeast-2.amazonaws.com/%ED%95%9C%EC%84%9C%EC%A7%84.jpg','UP',NULL,'parent4','2023-02-16 16:31:39.304000'),('PARENT',45,'부산 강서구 르노삼성대로 263','213','46726','ssafy@ssafy.io','천년줌','qwer1234!','01026078145','https://ssafy-hot-six.s3.ap-northeast-2.amazonaws.com/%EC%B2%9C%EB%85%84%EC%A4%8C.png','UP',NULL,'parent5','2023-02-16 16:32:47.741000');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-17  9:19:47
